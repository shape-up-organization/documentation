package school.sptech.login01221131eduarda.domain;

public class User {
    private String user;
    private String name;
    private boolean isAuthenticated;
    private String password;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean checkUserAndPassword(User userFor, String user, String password) {
        return userFor.user.equals(user) &&
                userFor.password.equals(password);
    }

    public boolean checkUserAndWrongPassword(User userFor, String user, String password) {
        return userFor.user.equals(user) &&
                !userFor.password.equals(password);
    }
}
