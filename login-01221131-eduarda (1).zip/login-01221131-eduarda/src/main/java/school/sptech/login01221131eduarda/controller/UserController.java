package school.sptech.login01221131eduarda.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import school.sptech.login01221131eduarda.domain.User;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    List<User> users;
    public UserController() {
        this.users = new ArrayList<>();
    }

    @GetMapping
    public List<User> allUsers(){
        return users;
    }

    /* Não é possível cadastrar o mesmo user na lista */
    @PostMapping
    public User createUser(@RequestBody User user)
    {
        for (User userFor: users) {
            if (userFor.getUser().equals(user.getUser()) ||
                    user.getName() == null && user.getUser() == null)
            {
                return null;
            }
        }
        users.add(user);

        return user;
    }

    @PostMapping("/authentication/{user}/{password}")
    public User authenticateUser(@PathVariable String user, @PathVariable String password){
        for (User userFor: users) {
            if (userFor.checkUserAndPassword(userFor, user, password))
            {
                userFor.setAuthenticated(true);
                return userFor;
            }
        }
        return null;
    }

    @DeleteMapping ("/authentication/{user}")
    public String logoffUser(@PathVariable String user){
        for (User userFor: users)
        {
            if (userFor.getUser().equals(user) && userFor.isAuthenticated())
            {
                userFor.setAuthenticated(false);
                return "Logoff do usuário "+ userFor.getName() + " concluído";
            }
            else if (userFor.getUser().equals(user) && !userFor.isAuthenticated())
            {
                return "Usuário "+ userFor.getName() + " NÃO está autenticado";
            }
        }
        return "Usuário "+ user + " não encontrado";
    }

    /*
    * PATCH - esse método é para alterar a senha,
    * Se o usuário e senha existem e estão corretos, altera a senha e retorna "Senha alterada com sucesso!",
    * Se o usuário existir mas a senha estiver errada, retorna "Senha antiga Errada" e não altera a senha,
    * Se o usuário não existir na lista, retorna "User X não encontrado"
    */
    @PatchMapping("/{user}/{oldPassword}/{newPassword}")
    public String changePassword(@PathVariable String user, @PathVariable String oldPassword,
                                 @PathVariable String newPassword){
        for (User userFor: users)
        {
            if (userFor.checkUserAndPassword(userFor, user, oldPassword))
            {
                userFor.setPassword(newPassword);
                return "Senha alterada com sucesso!";
            }
            else if (userFor.checkUserAndWrongPassword(userFor, user, oldPassword))
            {
                return "Senha antiga errada!";
            }
        }
        return "Usuário "+ user + " não encontrado";
    }
}
