package school.sptech.login01221131eduarda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login01221131EduardaApplicationTests {

    @Test
    void contextLoads() {
    }

}
