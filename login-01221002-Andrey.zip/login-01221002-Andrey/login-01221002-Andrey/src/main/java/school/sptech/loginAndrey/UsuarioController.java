package school.sptech.loginAndrey;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    private List<Usuario> usuarios;

    public UsuarioController() {
        this.usuarios = new ArrayList<>();
    }

    @PostMapping
    public Usuario singUp(@RequestBody Usuario novoUsuario) {
        this.usuarios.add(novoUsuario);
        return novoUsuario;
    }

    @PostMapping("/autenticate/{user}/{password}")
    public Usuario authenticate(@PathVariable String user, @PathVariable String password) {
        for (Usuario usuario : usuarios) {
            if (usuario.getUser().equals(user) && usuario.autenticateUser(password)) {

                usuario.setStatusAutenticate(true);
                return usuario;
            }

        }
        return null;
    }

    @GetMapping
    public List<Usuario> getUsers() {

        return usuarios;
    }

    @DeleteMapping("/autenticate/{user}")
    public String delete(@PathVariable String user) {
        for (Usuario usuario : usuarios) {
            if (usuario.getUser().contains(user) && usuario.isStatusAutenticate()) {
                usuario.setStatusAutenticate(false);
                return String.format("Logoff do usuario %s concluido", usuario.getName());
            } else if (usuario.getUser().contains(user) && usuario.isStatusAutenticate() != true) {
                return String.format("Usuario %s não esta autenticado", usuario.getName());

            }
        }
        return String.format("Usuario %s não encontrado", user);

    }


    /*
    Nesse metodo abaixo está sendo feita uma tentativa de exclusão de um usuario a partir de seu nome
    caso exista algum usuario com o mesmo nome que foi passado na assinatura do metodo ele será removido,
    e caso nao seja encontrado, nao tera nenhum retorno !!!
     */

    @DeleteMapping("/delete/{name}")
    public String deleteUserbyName(@PathVariable String name) {
        for (Usuario usuario : usuarios) {
            if (usuario.getName().equals(name)) {
                usuarios.remove(usuario);
                return String.format("Usuario %s removido com sucesso",name);
            }
        }
        return null;
    }

}




