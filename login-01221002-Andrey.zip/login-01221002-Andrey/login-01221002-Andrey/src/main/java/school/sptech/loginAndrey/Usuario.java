package school.sptech.loginAndrey;

public class Usuario {
    private String user;
    private String password;
    private String name;
    private boolean statusAutenticate;

    public Usuario() {
    }

    public Usuario(String user, String name, String password) {
        this.user = user;
        this.name = name;
        this.password = password;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isStatusAutenticate() {
        return statusAutenticate;
    }

    public void setStatusAutenticate(boolean statusAutenticate) {
        this.statusAutenticate = statusAutenticate;
    }

    public boolean autenticateUser(String password){
        if(this.password.equals(password)){
            return true;
        }
        return false;
    }



}
