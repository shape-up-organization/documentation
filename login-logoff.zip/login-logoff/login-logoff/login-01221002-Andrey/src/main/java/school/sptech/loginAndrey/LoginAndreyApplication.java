package school.sptech.loginAndrey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAndreyApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAndreyApplication.class, args);
	}

}
