package school.sptech.login01221094gabriel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login01221094GabrielApplicationTests {

    @Test
    void contextLoads() {
    }

}
