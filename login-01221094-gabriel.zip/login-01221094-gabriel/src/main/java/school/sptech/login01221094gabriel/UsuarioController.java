package school.sptech.login01221094gabriel;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();

    @PostMapping
    public Usuario cadastrar(@RequestBody Usuario usuario) {
        for (Usuario anUser : usuarios) {
            if(anUser.usuarioExiste(usuario.getUsuario())) {
                return null;
            }
        }

        usuarios.add(usuario);
        return usuario;
    }

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public Usuario autenticar(@PathVariable String usuario, @PathVariable String senha) {

        var usuarioAtual = usuarios.stream()
                .filter(anUser -> anUser.usuarioExiste(usuario, senha))
                .findFirst()
                .map(anUser -> {
                    anUser.autenticarUsuario();
                    return anUser;
                })
                .orElse(null);

        return usuarioAtual;
    }

    @GetMapping
    public List<Usuario> listaUsuarios() {
        return usuarios;
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String logoff(@PathVariable String usuario) {
        return usuarios.stream()
                .filter(anUser -> anUser.usuarioExiste(usuario))
                .findFirst()
                .map(anUser -> {
                    if (anUser.getAutenticacao().booleanValue()) {
                        anUser.setAutenticacao(false);
                        return String.format("Logoff do usuário %s concluído", anUser.getNome());
                    }
                    return String.format("Usuário %s NÃO está autenticado", anUser.getNome());
                }).get();
    }

    // Esse metodo atualiza o usuario. Ele informa o usuario que quer alterar na URI e passa tambem o novo usuario desejado.
    @PutMapping("/{usuario}/{novoUsuario}")
    public String alteraUsuario(@PathVariable String usuario, @PathVariable String novoUsuario) {
        return usuarios.stream()
                .filter(anUser -> anUser.usuarioExiste(usuario))
                .findFirst()
                .map(anUser -> {
                    anUser.setUsuario(novoUsuario);
                    return String.format("O usuario foi alterado de %s para %s", usuario, anUser.getUsuario());
                }).orElse(String.format("Usuario %s não existe.", usuario));
    }
}
