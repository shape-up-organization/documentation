package school.sptech.login01221094gabriel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login01221094GabrielApplication {

    public static void main(String[] args) {
        SpringApplication.run(Login01221094GabrielApplication.class, args);
    }

}
