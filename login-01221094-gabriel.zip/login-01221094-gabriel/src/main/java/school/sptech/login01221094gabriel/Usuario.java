package school.sptech.login01221094gabriel;

import java.util.Objects;

public class Usuario {
    private String nome;
    private String usuario;
    private String senha;

    private Boolean autenticacao = false;

    public Usuario() {

    }

    public Usuario(String nome, String usuario, String senha) {
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
    }

    public Boolean usuarioExiste(String usuario, String senha) {
        if (this.usuario.equals(usuario) && this.senha.equals(senha)) {
            return true;
        }

        return false;
    }

    public Boolean usuarioExiste(String usuario) {
        if (this.usuario.equals(usuario)) {
            return true;
        }

        return false;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void autenticarUsuario() {
        this.autenticacao = true;
    }

    public Boolean getAutenticacao() {
        return autenticacao;
    }
    public void setAutenticacao(boolean valor) {
        this.autenticacao = valor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Usuario usuario1)) return false;
        return nome.equals(usuario1.nome) && usuario.equals(usuario1.usuario) && senha.equals(usuario1.senha) && autenticacao.equals(usuario1.autenticacao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, usuario, senha, autenticacao);
    }
}
