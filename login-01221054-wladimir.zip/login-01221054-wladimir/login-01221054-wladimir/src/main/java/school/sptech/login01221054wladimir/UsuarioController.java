package school.sptech.login01221054wladimir;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private List<Usuario> listausers;
    private List<UsuarioSemSenha> listaSemSenha;

    public UsuarioController() {
        this.listausers = new ArrayList<>();
        this.listaSemSenha = new ArrayList<UsuarioSemSenha>();
    }

    @PostMapping
    public UsuarioSemSenha postUsuario(@RequestBody Usuario u1){
        UsuarioSemSenha u2 = new UsuarioSemSenha(u1.getUsuario(), u1.getSenha(), u1.getNome(), u1.getAutenticar());
        listausers.add(u1);
        listaSemSenha.add(u2);
        return u2;
    }
    @PostMapping("/autenticar/{usuario}/{senha}")
    public UsuarioSemSenha postAutenticar(@PathVariable String usuario, @PathVariable String senha){
        for (int i = 0 ; i < listausers.size(); i++){
            if (listausers.get(i).getUsuario().equals(usuario) && listausers.get(i).getSenha().equals(senha)){
                listausers.get(i).setAutenticar(true);
                listaSemSenha.get(i).setAutenticar(true);
                return listaSemSenha.get(i);
            }
        }
        return null;
    }
    @GetMapping
    public List getUsuarios(){
        return listaSemSenha;
    }
    @DeleteMapping("/autenticacao/{usuario}")
    public String logoffUsuario(@PathVariable String usuario){
        for (int i = 0 ; i < listausers.size() ; i++){
            if (listausers.get(i).getUsuario().equals(usuario)){
                if (listausers.get(i).getAutenticar().equals(true)){
                    listausers.get(i).setAutenticar(false);
                    listaSemSenha.get(i).setAutenticar(false);
                    return "Logoff do usuario " + listausers.get(i).getNome() + " concluido";
                }else {
                    return "usuario "+ listausers.get(i).getNome() + " não esta autenticado";
                }
            }
        }
        return "usuario " + usuario + " não encontrado";
    }
    @PutMapping("/atualizar/{usuario}/{senha}/{newNome}")
    public String putAtualizar(@PathVariable String usuario, @PathVariable String senha, @PathVariable String newNome){
        for (int i = 0 ; i < listausers.size(); i++){
            if (listausers.get(i).getUsuario().equals(usuario) && listausers.get(i).getSenha().equals(senha)){
                listausers.get(i).setNome(newNome);
                listaSemSenha.get(i).setNome(newNome);
                return "Nome atualizado";
            }
        }
        return "usuario não encontrado";
    }

}
