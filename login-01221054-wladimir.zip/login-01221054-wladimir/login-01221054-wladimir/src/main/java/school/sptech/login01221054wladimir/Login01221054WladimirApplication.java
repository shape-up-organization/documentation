package school.sptech.login01221054wladimir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login01221054WladimirApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login01221054WladimirApplication.class, args);
	}

}
