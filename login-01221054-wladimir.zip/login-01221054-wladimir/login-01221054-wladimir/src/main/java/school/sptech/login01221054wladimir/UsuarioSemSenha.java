package school.sptech.login01221054wladimir;

public class UsuarioSemSenha {
    private String usuario;
    private String senha;
    private String nome;
    private Boolean autenticar = false;

    public UsuarioSemSenha(String usuario, String senha, String nome, Boolean autenticar) {
        this.usuario = usuario;
        this.senha = senha;
        this.nome = nome;
        this.autenticar = autenticar;
    }

    public UsuarioSemSenha() {
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Boolean getAutenticar() {
        return autenticar;
    }

    public void setAutenticar(Boolean autenticar) {
        this.autenticar = autenticar;
    }

    @Override
    public String toString() {
        return "UsuarioSemSenha{" +
                "usuario='" + usuario + '\'' +
                ", senha='" + senha + '\'' +
                ", nome='" + nome + '\'' +
                ", autenticar=" + autenticar +
                '}';
    }
}
