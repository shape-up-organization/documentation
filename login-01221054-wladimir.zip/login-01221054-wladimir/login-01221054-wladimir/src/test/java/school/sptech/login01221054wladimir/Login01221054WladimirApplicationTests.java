package school.sptech.login01221054wladimir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Login01221054WladimirApplicationTests {

	@Test
	void contextLoads() {
	}

}
