package user;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/users")
public class UserController {

    private List<User> users;

    public UserController() {
        this.users = new ArrayList<>();
        this.users.add(new User("username1", "user1", "123", false));
        this.users.add(new User("username2", "user2", "456", true));
        this.users.add(new User("username3", "user3", "789", false));
    }

    @GetMapping
    public List<User> list() {
        return users;
    }

    @GetMapping("/{index}")
    public User listByIndex(@PathVariable int index) {
        if (index < 0 || users.isEmpty()) return null;

        return users.get(index);
    }

    @PostMapping
    public User create(@RequestBody User user) {
        if (Objects.isNull(user) || users.contains(user)) {
            return null;
        }

        user.setAuthenticated(false);
        this.users.add(user);
        return user;
    }

    @PostMapping("/auth/{username}/{password}")
    public User login(@PathVariable String username, @PathVariable String password) {
        if (Objects.isNull(username) || Objects.isNull(password)) return null;

        User user = users.stream().filter(u -> u.authenticate(username, password)).findFirst().orElse(null);

        return user;
    }

    @DeleteMapping("/auth/{username}")
    public String logoff(@PathVariable String username) {
        if (Objects.isNull(username)) return null;

        User user = users.stream().filter(u -> u.getUsername().equals(username)).findFirst().orElse(null);

        if (Objects.isNull(user)) return "User '" + user.getUsername() + "' not found!";

        if (user.isAuthenticated()) {
            user.setAuthenticated(false);
            return "User '" + user.getName() + "' logoff succeeded!";
        }

        return "User '" + user.getName() + "' IS NOT autheticated!";
    }

    // Change password with old password confirmation
    // Also autheticate the user to be able to reset password
    @PutMapping("/{index}/{password}/{newPassword}/{newPasswordConfirmation}")
    public String update(@PathVariable int index,
                         @PathVariable String password,
                         @PathVariable String newPassword,
                         @PathVariable String newPasswordConfirmation) {
        if (index < 0 || index > users.size() - 1 || users.isEmpty()) return "User not found!";
        if (Objects.isNull(password) ||
                Objects.isNull(newPassword) ||
                Objects.isNull(newPasswordConfirmation)) {
            return null;
        }

        User user = users.get(index);

        if (Objects.nonNull(login(user.getUsername(), password))) {
            if (Objects.isNull(user)) return "User not found!";
            if (!newPassword.equals(newPasswordConfirmation)) return "Passwords are not the same!";

            user.setPassword(newPassword);
            this.users.set(index, user);
            return "User '" + user.getName() + "' updated successfully!";
        }

        return "Password not correct!";
    }
}
